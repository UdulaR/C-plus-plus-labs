/*Ex2.h : Ex2 a2 CSI2372A*/


#include <iostream>
using namespace std;
const int sizeArray = 10;	//number of items in the array
void sort(int a[], int size); //declare sort in header file

